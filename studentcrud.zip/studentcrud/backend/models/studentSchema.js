const mongoose = require("mongoose");

const studentSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true },
    age: { type: Number, required: true },
    course: { type: String, required: true }
  },
  { timestamps: true } // for timestamp 
);

module.exports = mongoose.model("Student", studentSchema);

// it will creare a Students named databse for given schema 
