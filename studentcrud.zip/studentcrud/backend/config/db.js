const mongoose = require("mongoose");

const connectdb= async ()=>{

    try{
        await mongoose.connect(process.env.MONGODB_URI);
        console.log("database connected");
    }   
    catch(error){
            console.log("connecting error",error.message);
            process.exit(1);
    }
}

module.exports=connectdb;