<?php
$username = $_POST ['usernmae'];
$password = $_POST ['password'];

if (empty ($username) || empty ($password)) {
    echo "Both Fields are Required.";
} elseif ($username == "student" && $password == "anuj1234") {
    echo "Welcome, $usernmae !";
} else {
    echo "Invalid Login.";
}

?>