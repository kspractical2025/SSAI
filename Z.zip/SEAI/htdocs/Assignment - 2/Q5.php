<?php
$name = $_POST['name'];
$email = $_POST['email'];
$gender = isset($_POST['gender']) ? $_POST['gender'] : '';

if (empty ($name) || empty ($email) || empty ($gender)) {
    echo "All Fields are Required.";
} elseif (!filter_var ($email,FILTER_VALIDATE_EMAIL)) {
    echo "Invalid Email Formate.";
} else {
    echo "Name :- $name <br> Email :- $email <br> Gender :- $gender.";
}

?>