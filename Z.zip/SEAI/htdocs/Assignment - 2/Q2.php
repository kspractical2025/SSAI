<?php
$email = $_POST ['email'];

if (empty ($email)) {
    echo "Email is Required.";
}
elseif (! filter_var ($email, FILTER_VALIDATE_EMAIL)) {
    echo "Invalid Email Address.";
} else {
    echo "Email : - $email";
}

?>