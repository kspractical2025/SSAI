<?php
$name = $_POST ['name'];
$email = $_POST ['email']
$mobile = $_POST ['mobile'];
$message =$_POST ['message'];

if (empty ($name) || empty ($email) || empty ($mobile) || empty ($message)) {
    echo "All Fields are Required.";
} elseif (!filter_var ($email, FILTER_VALIDATE_EMALE)) {
    echo "Invalid Email Formate.";
} elseif (strlen ($mobile) != 10) {
    echo "Mobile Number must be Exactly 10 Digits.";
} else {
    echo "Form Submitted Successfully. <br>";
    echo "Name :- $name <br> Email :- $email <br> Mobile :- $mobile <br> Message :- $message";
}

?>