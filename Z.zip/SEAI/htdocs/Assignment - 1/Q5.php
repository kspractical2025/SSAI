<?php
$marks = 40;

if($marks > 35) {
    echo "Passed.";
}

?>