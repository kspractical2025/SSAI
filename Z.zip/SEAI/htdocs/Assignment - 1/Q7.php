<?php
$temp = 36;

if($temp >35) {
    echo "Hot.";
} else {
    echo "Normal.";
}

?>