<?php
$product = "Laptop";
$price = 75000.00;
$quantity = 2;
$total = $price * $quantity;

echo "Product :- $product <br> ";
echo "Total Cost :- $total";

?>