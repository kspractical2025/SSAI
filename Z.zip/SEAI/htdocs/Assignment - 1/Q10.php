<?php
$day = 3;

switch ($day) {
    case 1 : echo "Monday"; break;
    case 2 : echo "Tuesday"; break;
    case 3 : echo "Wednesday"; break;
    case 4 : echo "Thrusday"; break;
    case 5 : echo "Friday"; break;
    case 6 : echo "Saturday"; break;
    case 7 : echo "Sunday"; break;
    default : echo "Invalid Day Number.";
}

?>