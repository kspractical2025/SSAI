<?php
$number =120;

if($number > 100) {
    echo "The Number is Greater than 100.";
}

?>