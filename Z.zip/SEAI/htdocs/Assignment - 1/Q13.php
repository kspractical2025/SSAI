<?php
$i = 1;
$sum = 0;

while ($i <= 100) {
    $sum += $i;
    $i++;
}
echo "Sum = $sum";

?>