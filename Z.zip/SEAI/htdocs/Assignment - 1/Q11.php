<?php
$code = 'B';

switch ($code) {
    case 'C' : echo "Car."; break;
    case 'B' : echo "Bike."; break;
    case 'T' : echo "Truck."; break;
    default : echo "Invalid Code.";
}

?>