<?php
$age = 45;

if($age < 13) {
    echo "Child.";
} elseif ($age <= 19) {
    echo "Teenager.";
} elseif ($age <= 59) {
    echo "Adult.";
} else {
    echo "Senior Citizen.";
}

?>