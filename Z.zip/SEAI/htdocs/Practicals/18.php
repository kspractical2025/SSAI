<?php
$sentence = "PHP is easy to learn";

// String to array
$words = explode(" ", $sentence);

echo "Array<br />";
print_r($words);

// Reverse the array
$reversed = array_reverse($words);

echo "Reverse the array<br />";
print_r($reversed);

echo "<br />";
// Join back to string
$reversed_sentence = implode(",", $reversed);

echo "Original: $sentence<br />";
echo "Reversed: $reversed_sentence<br />";
?>
