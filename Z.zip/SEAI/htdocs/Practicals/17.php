<?php
$a = ["banana", "apple", "mango"];
$b = ["orange", "grape"];
$merged = array_merge($a, $b);

sort($merged);

print_r($merged);
?>