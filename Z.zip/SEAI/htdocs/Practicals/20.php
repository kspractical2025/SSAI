<?php
$text = "PHP is a powerful scripting language.";

// String functions
$word_count = str_word_count($text);
$char_count = strlen($text);
$upper_text = strtoupper($text);

echo "Original: $text<br />";
echo "Words: $word_count<br />";
echo "Characters: $char_count<br />";
echo "Uppercase: $upper_text<br />";
?>