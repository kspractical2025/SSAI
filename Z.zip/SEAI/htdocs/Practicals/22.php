<?php
// Start the session
session_start();

// Set session variables
$_SESSION["user_id"] = 101;

// Access session variables
echo "User ID is: " . $_SESSION["user_id"];

?>