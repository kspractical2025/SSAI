<?php
$numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
$even = [];

foreach ($numbers as $num) {
    if ($num % 2 === 0) {
        array_push($even, $num);
    }
}

print_r($even);
?>
