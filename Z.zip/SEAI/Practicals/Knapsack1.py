def MergeSort(array):
    if len(array) <= 1:
        return array

    mid = len(array) // 2
    leftHalf = array[:mid]
    rightHalf = array[mid:]

    sortedLeft = MergeSort(leftHalf)
    sortedRight = MergeSort(rightHalf)

    return merge(sortedLeft, sortedRight)

def merge(left, right):
    result = []
    i = j = 0

    while i < len(left) and j < len(right):
        if left[i] > right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1

    result.extend(left[i:])
    result.extend(right[j:])
 
    return result

def Fractional_Knapsack(Capacity, Weights, Values):
    n = len(Values)

    Items = []

    for i in range(n):
        Ratio = Values[i]/Weights[i]
        Items.append((Ratio, Values[i], Weights[i]))

    # Items.sort(reverse = True)
    Items = MergeSort(Items)
    Total_Value = 0.0

    for Ratio, Values, Weights in Items:
        if Capacity >= Weights:
            Capacity -= Weights
            Total_Value += Values

        else:
            Total_Value += Ratio * Capacity
            break

    return Total_Value

Values = [100, 60, 120]
Weights = [20, 10, 30]
Capacity = 15

Result1 = Fractional_Knapsack(Capacity, Weights, Values)
print("Maximum Value in Knapsack : - ", round(Result1, 2))