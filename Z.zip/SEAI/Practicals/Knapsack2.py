def QuickSort(array, low, high):
    if low < high:
        pivot = partition(array, low, high)
        QuickSort(array, low, pivot - 1)
        QuickSort(array, pivot + 1, high)

def partition(array, low, high):
    pivot = array[low]
    i = low + 1
    j = high

    while True:
        while i <= j and array[i] >= pivot:
            i += 1

        while i <= j and array[j] <= pivot:
            j -= 1 

        if i <= j:
            array[i], array[j] = array[j], array[i]

        else :
            break

    array[low], array[j] = array[j], array[low] 
    return j

def Fractional_Knapsack(Capacity, Weights, Values):
    n = len(Values)

    Items = []

    for i in range(n):
        Ratio = Values[i]/Weights[i]
        Items.append((Ratio, Values[i], Weights[i]))

    Items.sort(reverse = True)
    Total_Value = 0.0

    for Ratio, Values, Weights in Items:
        if Capacity >= Weights:
            Capacity -= Weights
            Total_Value += Values

        else:
            Total_Value += Ratio * Capacity
            break

    return Total_Value

Values = [100, 60, 120]
Weights = [20, 10, 30]
Capacity = 15

Result = Fractional_Knapsack(Capacity, Weights, Values)
print("Maximum Value in Knapsack : - ", round(Result, 2))