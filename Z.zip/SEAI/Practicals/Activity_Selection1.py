def QuickSort(f, low, high):
    if low < high:
        pivot = partition(f, low, high)
        QuickSort(f, low, pivot - 1)
        QuickSort(f, pivot + 1, high)

def partition(f, low, high):
    pivot = f[low]
    i = low + 1
    j = high

    while True:
        while i <= j and f[i] <= pivot:
            i += 1

        while i <= j and f[j] >= pivot:
            j -= 1 

        if i <= j:
            f[i], f[j] = f[j], f[i]

        else :
            break

    f[low], f[j] = f[j], f[low] 
    return j


def Activity_Selection1(start,finish):
    Activities = list(zip(start,finish))
    num = len(finish) - 1
    QuickSort(finish, 0, num)

    Selected = []
    Last_End = 0

    for s, f in Activities:
        if s >= Last_End:
            Selected.append((s,f))
            Last_End = f

    return Selected

start = [1, 3, 0, 5, 8, 5]
finish =[2, 4, 6, 7, 9, 9]

result = Activity_Selection1(start, finish)
print("Seleted Activities : - ", result)
print("Total Activities : - ", len(result))