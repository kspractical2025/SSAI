def Fractional_Knapsack(Capacity, Weights, Values):
    n = len(Values)

    Items = []

    for i in range(n):
        Ratio = Values[i]/Weights[i]
        Items.append((Ratio, Values[i], Weights[i]))

    Items.sort(reverse = True)
    Total_Value = 0.0

    for Ratio, Values, Weights in Items:
        if Capacity >= Weights:
            Capacity -= Weights
            Total_Value += Values

        else:
            Total_Value += Ratio * Capacity
            break

    return Total_Value

Values = [100, 60, 120]
Weights = [20, 10, 30]
Capacity = 50

Result = Fractional_Knapsack(Capacity, Weights, Values)
print("Maximum Value in Knapsack : - ", round(Result, 2))