def Fractional_Knapsack(Capacity, Weights, Values):
    n = len(Values)

    Items = []

    for i in range(n):
        Ratio = Values[i]/Weights[i]
        Items.append((Ratio, Values[i], Weights[i]))

    Items.sort(reverse = True)
    Total_Value = 0.0

    for Ratio, Values, Weights in Items:
        if Capacity >= Weights:
            Capacity -= Weights
            Total_Value += Values

        else:
            Total_Value += Ratio * Capacity
            break

    return Total_Value

Names = []
Values = []
Weights = []
Item = []
Capacity = int(input("Enter Capacity : - "))

Size = int(input("Enter Size : -"))
for i in range(Size):
    Name = (input("Enter Name : - "))
    Value = int(input("Enter Value : - "))
    Weight = int(input("Enter Weight : - "))
    # Ratio = Value / Weight
    # Item.append(Ratio)
    Names.append(Name)
    Values.append(Value)
    Weights.append(Weight)
    Item.append((Name, Value, Weight))

print("\nList of Items : -")
print("Name    Value    Weight")

for Items in Item:
    print(f"{Items[0]} \t {Items[1]} \t {Items[2]}")
    # print("Name : - ", Names[i])
    # print("Values : - ", Values[i]) 
    # print("Weight : - ", Weights[i])

Result = Fractional_Knapsack(Capacity, Weights, Values)
print("Maximum Value in Knapsack : - ", round(Result, 2))
