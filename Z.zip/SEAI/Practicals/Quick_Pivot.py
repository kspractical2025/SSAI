def Quick_Pivot(array, low = 0, high =None):
    if high is None:
        high = len(array) - 1 
    if low < high:
        pivot = partition(array, low, high)
        Quick_Pivot(array, low, pivot - 1)
        Quick_Pivot(array, pivot + 1, high)

def partition(array, low, high):
    pivot = array[high]
    i = low + 1
    j = high

    while True:
        while i <= j and array[i] <= pivot:
            i += 1

        while i <= j and array[j] >= pivot:
            j -= 1 

        if i <= j:
            array[i], array[j] = array[j], array[i]

        else :
            break

    array[low], array[j] = array[j], array[low] 
    return j

n = int(input("Enter Size : - "))

array1 = []

for i in range(0, n):
    temp = int(input("Enter Elements of The Array : -"))
    array1.append(temp)

num1 = len(array1)- 1
Quick_Pivot(array1, 0, num1)
print("Sorted Array : - ", array1)

array = [64, 34, 25, 5, 22, 11, 90, 12]
num = len(array)- 1
Quick_Pivot(array, 0, num)
print("Sorted Array : - ", array)
