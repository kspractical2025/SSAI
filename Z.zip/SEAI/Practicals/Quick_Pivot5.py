def partition(array, low, high):
    pivot = array[high]
    i = low - 1
    
    for j in range(low, high):
        if array[j] >= pivot:
            i += 1
            
            array[i], array[j] = array[j], array[i]
            
    array[i+1], array[high] = array[high], array[i+1]
    return i+1
    
def Quick_Pivot1(array, low=0, high=None):
    if high is None:
        high = len(array) - 1
 
    if low < high:
        pivot_index = partition(array, low, high)
        Quick_Pivot1(array, low, pivot_index-1)
        Quick_Pivot1(array, pivot_index+1, high)

size = int(input("Enter Size : - "))
mylist1 = input("Enter Array Sepreated by Space : - ")
number = list(map(int, mylist1.split()))
number1 = len(number) - 1
if (len(number) != size):
    print("Error : -")

else:
    Sorted_Array = Quick_Pivot1(number, 0, number1)
    print("Sorted Array : - ", number)

mylist = [64, 34, 25, 5, 22, 11, 90, 12]
Quick_Pivot1(mylist)
print(mylist)