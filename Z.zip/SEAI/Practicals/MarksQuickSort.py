def MarksQuickSort(marks, names, low, high):
    if low < high:
        pivot = partition(marks, names, low, high)
        MarksQuickSort(marks, names, low, pivot - 1)
        MarksQuickSort(marks, names, pivot + 1, high)

def partition(marks, names, low, high):
    pivot = marks[low]
    i = low + 1
    j = high

    while True:
        while i <= j and marks[i] <= pivot:
            i += 1

        while i <= j and marks[j] >= pivot:
            j -= 1 

        if i <= j:
            marks[i], marks[j] = marks[j], marks[i]
            names[i], names[j] = names[j], names[i]

        else :
            break

    marks[low], marks[j] = marks[j], marks[low]
    names[low], names[j] = names[j], names[low]
    return j

size = int(input("Enter Size : -"))

marks = []
names = []

for i in range(0,size):
    name = str(input("Enter Name : -"))
    mark = int(input("Enter Marks : -")) 

    marks.append(mark)
    names.append(name)

num = len(marks) - 1
MarksQuickSort(marks, names, 0, num)

print("Sorted Nmaes : -", names , "Sorted Marks : -", marks)