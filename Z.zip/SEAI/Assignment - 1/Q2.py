import random
import time

def merge_sort(arr):
    # Wrapper function that returns sorted array and count of inversions
    if len(arr) <= 1:
        return arr, 0
    mid = len(arr) // 2
    left, left_inv = merge_sort(arr[:mid])
    right, right_inv = merge_sort(arr[mid:])
    merged, split_inv = merge(left, right)
    total_inv = left_inv + right_inv + split_inv
    return merged, total_inv

def merge(left, right):
    merged = []
    i = j = 0
    inversions = 0
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            merged.append(left[i])
            i += 1
        else:
            # Inversion: elements remaining in left are all greater than right[j]
            merged.append(right[j])
            inversions += len(left) - i
            j += 1
    # Append any remaining elements
    merged.extend(left[i:])
    merged.extend(right[j:])
    return merged, inversions

def median(arr):
    n = len(arr)
    if n % 2 == 1:
        return arr[n // 2]
    else:
        return (arr[n // 2 - 1] + arr[n // 2]) / 2

def top_10_percent(arr):
    n = len(arr)
    cutoff = int(n * 0.9)
    return arr[cutoff:]

def total_revenue(arr):
    return sum(arr)

def main():
    # Generate random sales data
    sales = [round(random.uniform(10, 1000), 2) for _ in range(1000)]
    
    # Merge Sort with inversion count
    start = time.time()
    sorted_sales, inversions = merge_sort(sales)
    end = time.time()
    merge_sort_time = end - start

    print(f"Merge Sort Time: {merge_sort_time:.6f} seconds")
    print(f"Number of inversions (market volatility): {inversions}")
    
    # Calculate median
    med = median(sorted_sales)
    print(f"Median sale amount: {med}")

    # Calculate top 10% highest sales
    top_sales = top_10_percent(sorted_sales)
    print(f"Top 10% highest sales (count={len(top_sales)}):")
    print(top_sales[:10], "...")  # Show first 10 for brevity

    # Calculate total revenue
    revenue = total_revenue(sorted_sales)
    print(f"Total revenue: {revenue}")

    # Python built-in sort for comparison
    start = time.time()
    builtin_sorted = sorted(sales)
    end = time.time()
    builtin_sort_time = end - start
    print(f"Built-in sorted() Time: {builtin_sort_time:.6f} seconds")

    print(f"\nIs sorting correct? {builtin_sorted == sorted_sales}")

if __name__ == "__main__":
    main()
