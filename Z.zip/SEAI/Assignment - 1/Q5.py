class ReliefItem:
    def __init__(self, name, weight, value):
        self.name = name
        self.weight = weight
        self.value = value

def knapsack_01(items, capacity):
    n = len(items)
    dp = [[0]*(capacity+1) for _ in range(n+1)]

    for i in range(1, n+1):
        for w in range(capacity+1):
            if items[i-1].weight <= w:
                dp[i][w] = max(dp[i-1][w],
                               dp[i-1][w - items[i-1].weight] + items[i-1].value)
            else:
                dp[i][w] = dp[i-1][w]

    # Backtrack to find selected items
    w = capacity
    selected = []
    for i in range(n, 0, -1):
        if dp[i][w] != dp[i-1][w]:
            selected.append(items[i-1])
            w -= items[i-1].weight

    selected.reverse()
    total_value = dp[n][capacity]
    unused_capacity = capacity - sum(item.weight for item in selected)

    return selected, total_value, unused_capacity

def multiple_trucks_knapsack(items, capacity, trucks=2):
    remaining_items = items[:]
    trucks_loads = []
    total_value = 0

    for t in range(trucks):
        selected, value, unused = knapsack_01(remaining_items, capacity)
        trucks_loads.append((selected, value, unused))
        total_value += value

        # Remove selected items from remaining_items
        selected_set = set(selected)
        remaining_items = [item for item in remaining_items if item not in selected_set]

        if not remaining_items:
            break

    return trucks_loads, total_value

def greedy_knapsack(items, capacity):
    items_sorted = sorted(items, key=lambda x: x.value/x.weight, reverse=True)
    total_weight = 0
    total_value = 0
    selected = []

    for item in items_sorted:
        if total_weight + item.weight <= capacity:
            selected.append(item)
            total_weight += item.weight
            total_value += item.value

    unused_capacity = capacity - total_weight
    return selected, total_value, unused_capacity

def print_load(selected, value, unused_capacity, truck_id=None):
    if truck_id is not None:
        print(f"\nTruck {truck_id} Load:")
    else:
        print("\nSelected Items:")

    print(f"{'Item Name':15} {'Weight(kg)':>10} {'Value':>8}")
    print("-"*35)
    for item in selected:
        print(f"{item.name:15} {item.weight:10} {item.value:8}")
    print("-"*35)
    print(f"Total Value: {value}")
    print(f"Unused Capacity: {unused_capacity} kg")

def main():
    # Sample data: 20 items
    items = [
        ReliefItem("Food Packets", 10, 60),
        ReliefItem("Medicine Kits", 20, 100),
        ReliefItem("Blankets", 15, 90),
        ReliefItem("Water Bottles", 25, 120),
        ReliefItem("Tents", 30, 150),
        ReliefItem("Clothing", 12, 80),
        ReliefItem("Baby Food", 5, 30),
        ReliefItem("Sanitary Kits", 8, 40),
        ReliefItem("First Aid Kits", 10, 50),
        ReliefItem("Cooking Oil", 7, 35),
        ReliefItem("Fuel", 18, 70),
        ReliefItem("Tools", 9, 45),
        ReliefItem("Batteries", 6, 25),
        ReliefItem("Water Purifiers", 11, 55),
        ReliefItem("Masks", 3, 15),
        ReliefItem("Sanitizers", 4, 20),
        ReliefItem("Sleeping Bags", 16, 85),
        ReliefItem("Flashlights", 5, 28),
        ReliefItem("Radio Sets", 8, 40),
        ReliefItem("Generators", 25, 130),
    ]

    capacity = 50  # Each truck capacity in kg
    trucks = 2

    print("=== Exact 0/1 Knapsack for One Truck ===")
    selected, value, unused = knapsack_01(items, capacity)
    print_load(selected, value, unused)

    print("\n=== Exact 0/1 Knapsack for Multiple Trucks ===")
    trucks_loads, total_val = multiple_trucks_knapsack(items, capacity, trucks)
    for i, (sel, val, unused_cap) in enumerate(trucks_loads, 1):
        print_load(sel, val, unused_cap, truck_id=i)
    print(f"Total Value across {trucks} trucks: {total_val}")

    print("\n=== Greedy Approximate Solution for One Truck ===")
    selected_g, val_g, unused_g = greedy_knapsack(items, capacity)
    print_load(selected_g, val_g, unused_g)

    # Compare greedy vs exact for one truck
    print("\nComparison:")
    print(f"Exact Value: {value}, Greedy Value: {val_g}")
    if val_g < value:
        print("Greedy solution is suboptimal compared to exact knapsack.")
    else:
        print("Greedy solution matches or exceeds exact solution (rare).")

    # Conclusion
    print("\nConclusion:")
    print("In disaster relief, exact optimization using 0/1 Knapsack ensures the most valuable")
    print("resources are prioritized within the truck capacity, maximizing aid effectiveness.")
    print("Greedy methods are faster but can miss optimal combinations, risking suboptimal aid allocation.")
    print("Thus, exact methods are preferable despite computational overhead.")

if __name__ == "__main__":
    main()
