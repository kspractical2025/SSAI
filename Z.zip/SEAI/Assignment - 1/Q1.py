import random
import string

class Student:
    def __init__(self, roll_no, name, cgpa):
        self.roll_no = roll_no
        self.name = name
        self.cgpa = cgpa

    def __repr__(self):
        return f"Roll: {self.roll_no}, Name: {self.name}, CGPA: {self.cgpa}"

# Quick Sort implementation
def quick_sort(arr, low, high):
    if low < high:
        pi = partition(arr, low, high)
        quick_sort(arr, low, pi - 1)
        quick_sort(arr, pi + 1, high)

def partition(arr, low, high):
    pivot = arr[high]
    i = low - 1
    for j in range(low, high):
        # Compare based on CGPA (descending), if tie then name ascending
        if (arr[j].cgpa > pivot.cgpa) or (arr[j].cgpa == pivot.cgpa and arr[j].name < pivot.name):
            i += 1
            arr[i], arr[j] = arr[j], arr[i]
    arr[i+1], arr[high] = arr[high], arr[i+1]
    return i+1

# Binary Search for Roll Number
def binary_search(arr, roll_no):
    low = 0
    high = len(arr) - 1
    while low <= high:
        mid = (low + high) // 2
        if arr[mid].roll_no == roll_no:
            return arr[mid]
        elif arr[mid].roll_no < roll_no:
            low = mid + 1
        else:
            high = mid - 1
    return None

# Generate random student records for testing
def generate_random_students(n=50):
    students = []
    for i in range(n):
        roll_no = random.randint(1000, 9999)
        name = ''.join(random.choices(string.ascii_uppercase, k=5))
        cgpa = round(random.uniform(5.0, 10.0), 2)
        students.append(Student(roll_no, name, cgpa))
    return students

def main():
    students = generate_random_students(50)
    
    print("Original Student Records:")
    for s in students:
        print(s)
    
    # Sort students by CGPA descending and then name ascending
    quick_sort(students, 0, len(students) - 1)
    
    print("\nSorted Student Records (by CGPA desc, then Name asc):")
    for s in students:
        print(s)

    # For Binary Search to work by Roll Number, sort array by Roll Number ascending
    # We need to do this to perform binary search on roll_no
    # Because after the first sort, data is sorted by CGPA and name, not by roll_no.
    # Alternatively, we can do linear search on roll_no, but since question wants binary search:
    # So let's create a copy sorted by roll_no ascending.

    students_by_roll = sorted(students, key=lambda x: x.roll_no)
    print("\nStudent Records sorted by Roll Number for binary search:")
    for s in students_by_roll:
        print(s)

    # Search for a roll number
    search_roll = students_by_roll[random.randint(0, 49)].roll_no
    print(f"\nSearching for Roll Number: {search_roll}")
    found = binary_search(students_by_roll, search_roll)
    if found:
        print("Record Found:", found)
    else:
        print("Record Not Found")

if __name__ == "__main__":
    main()
