class Item:
    def __init__(self, name, weight, price):
        self.name = name
        self.weight = weight
        self.price = price
        self.price_per_weight = price / weight

def knapsack_01(items, capacity):
    n = len(items)
    # dp[i][w] = max price using first i items with capacity w
    dp = [[0] * (capacity + 1) for _ in range(n + 1)]

    for i in range(1, n + 1):
        for w in range(capacity + 1):
            if items[i-1].weight <= w:
                dp[i][w] = max(dp[i-1][w],
                               dp[i-1][w - int(items[i-1].weight)] + items[i-1].price)
            else:
                dp[i][w] = dp[i-1][w]

    # Backtracking to find selected items
    w = capacity
    selected = []
    for i in range(n, 0, -1):
        if dp[i][w] != dp[i-1][w]:
            selected.append(items[i-1])
            w -= int(items[i-1].weight)

    selected.reverse()
    return dp[n][capacity], selected

def fractional_knapsack(items, capacity):
    items.sort(key=lambda x: x.price_per_weight, reverse=True)
    total_price = 0.0
    remaining = capacity
    selected = []

    for item in items:
        if remaining <= 0:
            break
        if item.weight <= remaining:
            # Take whole item
            selected.append((item, item.weight))
            total_price += item.price
            remaining -= item.weight
        else:
            # Take fraction
            fraction = remaining / item.weight
            selected.append((item, remaining))
            total_price += item.price * fraction
            remaining = 0

    return total_price, selected

def print_receipt_01(selected, total_price):
    print("\n0/1 Knapsack Receipt:")
    print(f"{'Item Name':10} {'Qty':>7} {'Price':>10}")
    print("-" * 30)
    for item in selected:
        print(f"{item.name:10} {item.weight:7} {item.price:10.2f}")
    print("-" * 30)
    print(f"Total: ₹{total_price:.2f}")

def print_receipt_fractional(selected, total_price):
    print("\nFractional Knapsack Receipt:")
    print(f"{'Item Name':10} {'Qty/Weight':>12} {'Price':>10}")
    print("-" * 35)
    for item, qty in selected:
        price = item.price_per_weight * qty
        print(f"{item.name:10} {qty:12.2f} {price:10.2f}")
    print("-" * 35)
    print(f"Total: ₹{total_price:.2f}")

def main():
    # Sample dataset
    items = [
        Item("Rice", 5, 250),
        Item("Oil", 2, 300),
        Item("Flour", 3, 180),
        Item("Sugar", 4, 200),
        Item("Salt", 1, 50),
    ]

    capacity = 7  # Cart capacity in kg

    # 0/1 Knapsack
    total_01, selected_01 = knapsack_01(items, capacity)
    print_receipt_01(selected_01, total_01)

    # Fractional Knapsack
    total_frac, selected_frac = fractional_knapsack(items, capacity)
    print_receipt_fractional(selected_frac, total_frac)

    # Comparison
    print(f"\n0/1 Knapsack Total Price: ₹{total_01:.2f}")
    print(f"Fractional Knapsack Total Price: ₹{total_frac:.2f}")

    if total_frac > total_01:
        print("Fractional Knapsack yields higher total price due to partial item selection.")
    else:
        print("0/1 Knapsack is optimal for discrete items.")

    # Time complexity analysis
    print("\nTime Complexity Analysis:")
    print("0/1 Knapsack: O(n * capacity)")
    print("Fractional Knapsack: O(n log n) due to sorting")

    # Real-world limitations discussion
    print("\nReal-world limitations:")
    print("- 0/1 Knapsack assumes items can only be taken whole, not always practical for some items.")
    print("- Fractional Knapsack works well for divisible goods (e.g., rice), but not for discrete items (e.g., bottles).")
    print("- 0/1 Knapsack dynamic programming can be slow for very large capacities.")
    print("- Fractional Knapsack is greedy and faster but less applicable to all item types.")

if __name__ == "__main__":
    main()
