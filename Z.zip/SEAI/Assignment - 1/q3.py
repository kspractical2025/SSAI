from datetime import datetime, timedelta

class Talk:
    def __init__(self, start, end, topic):
        self.start = start  # datetime object
        self.end = end      # datetime object
        self.topic = topic
        self.duration = (end - start).total_seconds() / 60  # duration in minutes

    def __repr__(self):
        return f"{self.start.strftime('%H:%M')}-{self.end.strftime('%H:%M')}: {self.topic}"

def activity_selection(talks):
    # Sort talks by end time
    talks.sort(key=lambda x: x.end)
    selected = []
    last_end = None
    for talk in talks:
        if last_end is None or talk.start >= last_end:
            selected.append(talk)
            last_end = talk.end
    return selected

def activity_selection_modified(talks):
    # Sort by start time first to detect overlaps
    talks.sort(key=lambda x: x.start)
    selected = []
    i = 0
    while i < len(talks):
        current = talks[i]
        j = i + 1
        # Find all talks overlapping with current
        overlapping = [current]
        while j < len(talks) and talks[j].start < current.end:
            overlapping.append(talks[j])
            j += 1
        # Select talk with longest duration among overlapping
        best = max(overlapping, key=lambda x: x.duration)
        selected.append(best)
        # Skip all talks that overlap with chosen one
        i = j
        # Adjust i if chosen talk ended later than current
        while i < len(talks) and talks[i].start < best.end:
            i += 1
    # Sort selected by start time for timeline
    selected.sort(key=lambda x: x.start)
    return selected

def print_schedule(talks):
    print("\nFinal Schedule:")
    for talk in talks:
        print(talk)

def compute_utilized_idle(talks, conference_start, conference_end):
    utilized = sum(t.duration for t in talks)
    total = (conference_end - conference_start).total_seconds() / 60
    idle = total - utilized
    return utilized, idle

def two_halls_schedule(talks):
    # Sort by start time
    talks.sort(key=lambda x: x.start)
    hall_a = []
    hall_b = []

    # Keep track of last end time in each hall
    end_a = None
    end_b = None

    for talk in talks:
        # If talk fits in hall A
        if end_a is None or talk.start >= end_a:
            hall_a.append(talk)
            end_a = talk.end
        # Else if fits in hall B
        elif end_b is None or talk.start >= end_b:
            hall_b.append(talk)
            end_b = talk.end
        else:
            # Conflict, can't schedule in either hall
            # We skip or could try more complex heuristics
            pass

    # Sort final schedules by start time
    hall_a.sort(key=lambda x: x.start)
    hall_b.sort(key=lambda x: x.start)
    return hall_a, hall_b

# Helper to create datetime objects easily
def create_time(hour, minute=0):
    return datetime(2025, 1, 1, hour, minute)

def main():
    # Example talks
    talks = [
        Talk(create_time(9), create_time(10), "AI Talk"),
        Talk(create_time(9, 30), create_time(11), "Blockchain"),
        Talk(create_time(10), create_time(11), "Cybersecurity"),
        Talk(create_time(11), create_time(12), "Cloud Computing"),
        Talk(create_time(11, 30), create_time(13), "Data Science"),
        Talk(create_time(12), create_time(13), "Quantum Computing"),
        Talk(create_time(13), create_time(14), "IoT"),
        Talk(create_time(14), create_time(15), "Machine Learning"),
        Talk(create_time(14, 30), create_time(16), "Augmented Reality"),
        Talk(create_time(15), create_time(16), "Big Data"),
    ]

    conference_start = create_time(9)
    conference_end = create_time(17)

    print("Original Talks:")
    for t in talks:
        print(t)

    # Task 1: Classic Activity Selection
    selected = activity_selection(talks.copy())
    print("\nSelected Talks (Classic):")
    print_schedule(selected)

    # Task 2: Modified selection choosing longest duration on overlap
    selected_mod = activity_selection_modified(talks.copy())
    print("\nSelected Talks (Modified for longest duration on overlap):")
    print_schedule(selected_mod)

    # Task 4: Utilized vs Idle time for modified selection
    utilized, idle = compute_utilized_idle(selected_mod, conference_start, conference_end)
    print(f"\nTotal Utilized Time: {utilized:.1f} minutes")
    print(f"Total Idle Time: {idle:.1f} minutes")

    # Task 5: Two halls scheduling
    hall_a, hall_b = two_halls_schedule(talks.copy())
    print("\nHall A Schedule:")
    print_schedule(hall_a)

    print("\nHall B Schedule:")
    print_schedule(hall_b)

    total_talks = len(hall_a) + len(hall_b)
    print(f"\nTotal talks scheduled across two halls: {total_talks}")

if __name__ == "__main__":
    main()
