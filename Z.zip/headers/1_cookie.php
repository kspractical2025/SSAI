<?php
// Set a cookie that lasts 1 hour
setcookie("username", "Bhagirathsinh Chauhan", time() + 3600, "/");

// Access the cookie
if (isset($_COOKIE["username"])) {
    echo "Welcome back, " . $_COOKIE["username"];
}