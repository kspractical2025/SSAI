<?php
// Redirect to login page
header("Location: 3_2_redirected_page.php");
exit;
