<?php
header("Content-Disposition: attachment; filename=\"example.pdf\"");
header("Content-Type: application/pdf");
readfile("Sessions_Cookies_and_Header_Redirection_in_PHP.pdf");