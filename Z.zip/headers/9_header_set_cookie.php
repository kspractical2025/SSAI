<?php
header("Set-Cookie: test=value; path=/; HttpOnly");
