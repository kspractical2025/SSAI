CREATE DATABASE first;
USE first;

CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100)
);

INSERT INTO students (name, email) VALUES 
('Amit Shah', 'amit@example.com'),
('Seema Rai', 'seema@example.com');