<?php
$conn = mysqli_connect("localhost", "root", "", "first");

$name = "Raj Patel";
$email = "raj@example.com";

$sql = "INSERT INTO students (name, email) VALUES ('$name', '$email')";

if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . mysqli_error($conn);
}

mysqli_close($conn);
?>
