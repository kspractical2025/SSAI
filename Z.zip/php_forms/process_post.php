<?php
// process_post.php

// The data is sent in the body of the HTTP request (not visible in URL)
// $_POST is used to retrieve the form values

$email = $_POST['email'];
$password = $_POST['password'];

echo "Login details received.<br>";
echo "Email: $email<br>";
// Password should never be displayed in real apps – shown here just for learning.
echo "Password: $password";
?>