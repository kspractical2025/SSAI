<?php
$sentence = "Learning PHP is fun and productive.";
$word = "and";

if ($pos = strpos($sentence, $word) !== false) {
    echo "'$word' found in sentence.<br />";
} else {
    echo "'$word' not found.<br />";
}

echo "Position of '$word': $pos<br />";
?>
