<?php
// validate1.php

if (empty($_POST['name'])) {
    echo "Name is required.";
} else {
    $name = htmlspecialchars($_POST['name']); // prevents XSS
    echo "Welcome, $name!";
}
?>