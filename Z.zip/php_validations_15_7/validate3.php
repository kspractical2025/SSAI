<?php
// validate3.php

$name = trim($_POST['name']);
$email = trim($_POST['email']);
$message = trim($_POST['message']);

$errors = [];

if (empty($name)) {
    $errors[] = "Name is required.";
}


if (empty($email)) {
    $errors[] = "Email is required.";
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = "Email format is invalid.";
}

if (empty($message)) {
    $errors[] = "Message is required.";
}

if (count($errors) > 0) {
    foreach ($errors as $err) {
        echo $err . "<br>";
    }
} else {
    echo "Form submitted successfully!<br>";
    echo "Name: " . htmlspecialchars($name) . "<br>";
    echo "Email: " . htmlspecialchars($email) . "<br>";
    echo "Message: " . nl2br($message);
}
?>
