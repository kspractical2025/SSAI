Q1. MergeSort.py

def mergeSort(arr):
    if len(arr) <= 1:
        return arr

    mid = len(arr) // 2
    leftHalf = arr[:mid]
    rightHalf = arr[mid:]

    sortedLeft = mergeSort(leftHalf)
    sortedRight = mergeSort(rightHalf)

    return merge(sortedLeft, sortedRight)

def merge(left, right):
    result = []
    i = j = 0

    while i < len(left) and j < len(right):
        if left[i] < right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1

    result.extend(left[i:])
    result.extend(right[j:])
 
    return result

n = int(input("Enter Size : - "))

mylist1 = []

for i in range(0, n):
    temp = int(input("Enter Elements of The Array : -"))
    mylist1.append(temp)

mysortedlist1 = mergeSort(mylist1)
print("Sorted Array :- ", mysortedlist1)

mylist = [3, 7, 6, -10, 15, 23.5, 55, -13]
mysortedlist = mergeSort(mylist)
print("Sorted Array :- ", mysortedlist)

Q2. MergeSort1.py

def mergeSort1(arr):
    if len(arr) <= 1:
        return arr

    mid = len(arr) // 2
    leftHalf = arr[:mid]
    rightHalf = arr[mid:]

    sortedLeft = mergeSort1(leftHalf)
    sortedRight = mergeSort1(rightHalf)

    return merge(sortedLeft, sortedRight)

def merge(left, right):
    result = []
    i = j = 0

    while i < len(left) and j < len(right):
        if left[i] > right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1

    result.extend(left[i:])
    result.extend(right[j:])
 
    return result

n = int(input("Enter Size : - "))

mylist1 = []

for i in range(0, n):
    temp = int(input("Enter Elements of The Array : -"))
    mylist1.append(temp)

mysortedlist1 = mergeSort1(mylist1)
print("Sorted Array :- ", mysortedlist1)

mylist = [3, 7, 6, -10, 15, 23.5, 55, -13]
mysortedlist = mergeSort1(mylist)
print("Sorted Array :- ", mysortedlist)

Q3. QuickSort.py

def partition(array, low, high):
    pivot = array[high]
    i = low - 1

    for j in range(low, high):
        if array[j] <= pivot:
            i += 1
            array[i], array[j] = array[j], array[i]

    array[i+1], array[high] = array[high], array[i+1]
    return i+1

def quicksort(array, low=0, high=None):
    if high is None:
        high = len(array) - 1

    if low < high:
        pivot_index = partition(array, low, high)
        quicksort(array, low, pivot_index-1)
        quicksort(array, pivot_index+1, high)

n = int(input("Enter Size : - "))

mylist1 = []

for i in range(0, n):
    temp = int(input("Enter Elements of The Array : -"))
    mylist1.append(temp)

quicksort(mylist1)
print("Sorted Array : - ", mylist1)

mylist = [64, 34, 25, 5, 22, 11, 90, 12]
quicksort(mylist)
print("Sorted Array : - ",mylist)

Q4.QuickSort1.py

def partition(array, low, high):
    pivot = array[high]
    i = low - 1

    for j in range(low, high):
        if array[j] >= pivot:
            i += 1
            array[i], array[j] = array[j], array[i]

    array[i+1], array[high] = array[high], array[i+1]
    return i+1

def quicksort1(array, low=0, high=None):
    if high is None:
        high = len(array) - 1

    if low < high:
        pivot_index = partition(array, low, high)
        quicksort1(array, low, pivot_index-1)
        quicksort1(array, pivot_index+1, high)

n = int(input("Enter Size : - "))

mylist1 = []

for i in range(0, n):
    temp = int(input("Enter Elements of The Array : -"))
    mylist1.append(temp)

quicksort1(mylist1)
print("Sorted Array : - ", mylist1)

mylist = [64, 34, 25, 5, 22, 11, 90, 12]
quicksort1(mylist)
print("Sorted Array : - ",mylist)

Q5.QuickSort2.py

def QuickSort2(array, low, high):
    if low < high:
        pivot = partition(array, low, high)
        QuickSort2(array, low, pivot - 1)
        QuickSort2(array, pivot + 1, high)

def partition(array, low, high):
    pivot = array[low]
    i = low + 1
    j = high

    while True:
        while i <= j and array[i] <= pivot:
            i += 1

        while i <= j and array[j] >= pivot:
            j -= 1 

        if i <= j:
            array[i], array[j] = array[j], array[i]

        else :
            break

    array[low], array[j] = array[j], array[low] 
    return j

n = int(input("Enter Size : - "))

array1 = []

for i in range(0, n):
    temp = int(input("Enter Elements of The Array : -"))
    array1.append(temp)

num1 = len(array1)- 1
QuickSort2(array1, 0, num1)
print("Sorted Array : - ", array1)

array = [64, 34, 25, 5, 22, 11, 90, 12]
num = len(array)- 1
QuickSort2(array, 0, num)
print("Sorted Array : - ", array)

Q6.QuickSort3.py

def QuickSort3(array, low, high):
    if low < high:
        pivot = partition(array, low, high)
        QuickSort3(array, low, pivot - 1)
        QuickSort3(array, pivot + 1, high)

def partition(array, low, high):
    pivot = array[low]
    i = low + 1
    j = high

    while True:
        while i <= j and array[i] >= pivot:
            i += 1

        while i <= j and array[j] <= pivot:
            j -= 1 

        if i <= j:
            array[i], array[j] = array[j], array[i]

        else :
            break

    array[low], array[j] = array[j], array[low] 
    return j

n = int(input("Enter Size : - "))

array1 = []

for i in range(0, n):
    temp = int(input("Enter Elements of The Array : -"))
    array1.append(temp)

num1 = len(array1)- 1
QuickSort3(array1, 0, num1)
print("Sorted Array : - ", array1)

array = [64, 34, 25, 5, 22, 11, 90, 12]
num = len(array)- 1
QuickSort3(array, 0, num)
print("Sorted Array : -", array)

Q7.Quick_Pivot.py

def Quick_Pivot(array, low = 0, high =None):
    if high is None:
        high = len(array) - 1 
    if low < high:
        pivot = partition(array, low, high)
        Quick_Pivot(array, low, pivot - 1)
        Quick_Pivot(array, pivot + 1, high)

def partition(array, low, high):
    pivot = array[high]
    i = low + 1
    j = high

    while True:
        while i <= j and array[i] <= pivot:
            i += 1

        while i <= j and array[j] >= pivot:
            j -= 1 

        if i <= j:
            array[i], array[j] = array[j], array[i]

        else :
            break

    array[low], array[j] = array[j], array[low] 
    return j

n = int(input("Enter Size : - "))

array1 = []

for i in range(0, n):
    temp = int(input("Enter Elements of The Array : -"))
    array1.append(temp)

num1 = len(array1)- 1
Quick_Pivot(array1, 0, num1)
print("Sorted Array : - ", array1)

array = [64, 34, 25, 5, 22, 11, 90, 12]
num = len(array)- 1
Quick_Pivot(array, 0, num)
print("Sorted Array : - ", array)

Q8.Quick_Pivot1.py

def partition(array, low, high):
    pivot = array[high]
    i = low - 1
    
    for j in range(low, high):
        if array[j] <= pivot:
            i += 1
            
            array[i], array[j] = array[j], array[i]
            
    array[i+1], array[high] = array[high], array[i+1]
    return i+1
    
def quicksort(array, low=0, high=None):
    if high is None:
        high = len(array) - 1
 
    if low < high:
        pivot_index = partition(array, low, high)
        quicksort(array, low, pivot_index-1)
        quicksort(array, pivot_index+1, high)

mylist = [64, 34, 25, 5, 22, 11, 90, 12]
quicksort(mylist)
print(mylist)

Q9.Quick_Pivot2.py

def Quick_Pivot2(array, low, high): 
    if low < high:
        pivot = partition(array, low, high)
        Quick_Pivot2(array, low, pivot - 1)
        Quick_Pivot2(array, pivot + 1, high)

def partition(array, low, high):
    pivot = array[high]
    i = low 
    j = high - 1

    while True:
        while i <= j and array[i] <= pivot:
            i += 1

        while i <= j and array[j] >= pivot:
            j -= 1 

        if i <= j:
            array[i], array[j] = array[j], array[i]

        else :
            break

    array[i], array[high] = array[high], array[i] 
    return i

size = int(input("Enter Size : - "))
Number = input("Enter Array Sepreated by Space : - ")
num2 = list(map(int, Number.split()))
num3 = len(num2) - 1
if (len(num2) != size):
    print("Error : -")

else:
    Sorted_Array = Quick_Pivot2(num2, 0, num3)
    print("Sorted Array : - ", num2)

array = [64, 34, 25, 5, 22, 11, 90, 12]
num = len(array)- 1
Quick_Pivot2(array, 0, num)
print("Sorted Array : - ", array)

Q10.Quick_pivot3.py

def Quick_Pivot2(array, low, high): 
    if low < high:
        pivot = partition(array, low, high)
        Quick_Pivot2(array, low, pivot - 1)
        Quick_Pivot2(array, pivot + 1, high)

def partition(array, low, high):
    pivot = array[high]
    i = low 
    j = high - 1

    while True:
        while i <= j and array[i] >= pivot:
            i += 1

        while i <= j and array[j] <= pivot:
            j -= 1 

        if i <= j:
            array[i], array[j] = array[j], array[i]

        else :
            break

    array[i], array[high] = array[high], array[i] 
    return i

size = int(input("Enter Size : - "))
Number = input("Enter Array Sepreated by Space : - ")
num2 = list(map(int, Number.split()))
num3 = len(num2) - 1
if (len(num2) != size):
    print("Error : -")

else:
    Sorted_Array = Quick_Pivot2(num2, 0, num3)
    print("Sorted Array : - ", num2)

array = [64, 34, 25, 5, 22, 11, 90, 12]
num = len(array)- 1
Quick_Pivot2(array, 0, num)
print("Sorted Array : - ", array)

Q11. MarksQuickSort.py

def MarksQuickSort(marks, names, low, high):
    if low < high:
        pivot = partition(marks, names, low, high)
        MarksQuickSort(marks, names, low, pivot - 1)
        MarksQuickSort(marks, names, pivot + 1, high)

def partition(marks, names, low, high):
    pivot = marks[low]
    i = low + 1
    j = high

    while True:
        while i <= j and marks[i] <= pivot:
            i += 1

        while i <= j and marks[j] >= pivot:
            j -= 1 

        if i <= j:
            marks[i], marks[j] = marks[j], marks[i]
            names[i], names[j] = names[j], names[i]

        else :
            break

    marks[low], marks[j] = marks[j], marks[low]
    names[low], names[j] = names[j], names[low]
    return j

size = int(input("Enter Size : -"))

marks = []
names = []

for i in range(0,size):
    name = str(input("Enter Name : -"))
    mark = int(input("Enter Marks : -")) 

    marks.append(mark)
    names.append(name)

num = len(marks) - 1
MarksQuickSort(marks, names, 0, num)

print("Sorted Nmaes : -", names , "Sorted Marks : -", marks)

Q12.Activity_Selection.py

def Activity_Selection(start,finish):
    Activities = list(zip(start,finish))
    Activities.sort(key = lambda x : x[1])

    Selected = []
    Last_End = 0

    for s, f in Activities:
        if s >= Last_End:
            Selected.append((s,f))
            Last_End = f

    return Selected

start = [1, 3, 0, 5, 8, 5]
finish =[2, 4, 6, 7, 9, 9]

result = Activity_Selection(start, finish)
print("Seleted Activities : - ", result)
print("Total Activities : - ", len(result))

Q13.Acttivity_Selection1.py

def QuickSort(f, low, high):
    if low < high:
        pivot = partition(f, low, high)
        QuickSort(f, low, pivot - 1)
        QuickSort(f, pivot + 1, high)

def partition(f, low, high):
    pivot = f[low]
    i = low + 1
    j = high

    while True:
        while i <= j and f[i] <= pivot:
            i += 1

        while i <= j and f[j] >= pivot:
            j -= 1 

        if i <= j:
            f[i], f[j] = f[j], f[i]

        else :
            break

    f[low], f[j] = f[j], f[low] 
    return j


def Activity_Selection1(start,finish):
    Activities = list(zip(start,finish))
    num = len(finish) - 1
    QuickSort(finish, 0, num)

    Selected = []
    Last_End = 0

    for s, f in Activities:
        if s >= Last_End:
            Selected.append((s,f))
            Last_End = f

    return Selected

start = [1, 3, 0, 5, 8, 5]
finish =[2, 4, 6, 7, 9, 9]

result = Activity_Selection1(start, finish)
print("Seleted Activities : - ", result)
print("Total Activities : - ", len(result))

Q14.Activity_Selection2.py

def MergeSort(array):
    if len(array) <= 1:
        return array

    mid = len(array) // 2
    leftHalf = array[:mid]
    rightHalf = array[mid:]

    sortedLeft = MergeSort(leftHalf)
    sortedRight = MergeSort(rightHalf)

    return merge(sortedLeft, sortedRight)

def merge(left, right):
    result = []
    i = j = 0

    while i < len(left) and j < len(right):
        if left[i] < right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1

    result.extend(left[i:])
    result.extend(right[j:])
 
    return result

def Activity_Selection1(start,finish):
    Activities = list(zip(start,finish))
    MergeSort(finish)

    Selected = []
    Last_End = 0

    for s, f in Activities:
        if s >= Last_End:
            Selected.append((s,f))
            Last_End = f

    return Selected

start = [1, 3, 0, 5, 8, 5]
finish =[2, 4, 6, 7, 9, 9]

result = Activity_Selection1(start, finish)
print("Seleted Activities : - ", result)
print("Total Activities : - ", len(result))

Q15.Knapsack.py

def Fractional_Knapsack(Capacity, Weights, Values):
    n = len(Values)

    Items = []

    for i in range(n):
        Ratio = Values[i]/Weights[i]
        Items.append((Ratio, Values[i], Weights[i]))

    Items.sort(reverse = True)
    Total_Value = 0.0

    for Ratio, Values, Weights in Items:
        if Capacity >= Weights:
            Capacity -= Weights
            Total_Value += Values

        else:
            Total_Value += Ratio * Capacity
            break

    return Total_Value

Values = [100, 60, 120]
Weights = [20, 10, 30]
Capacity = 50

Result = Fractional_Knapsack(Capacity, Weights, Values)
print("Maximum Value in Knapsack : - ", round(Result, 2))

Q16.Knapsack1.py

def MergeSort(array):
    if len(array) <= 1:
        return array

    mid = len(array) // 2
    leftHalf = array[:mid]
    rightHalf = array[mid:]

    sortedLeft = MergeSort(leftHalf)
    sortedRight = MergeSort(rightHalf)

    return merge(sortedLeft, sortedRight)

def merge(left, right):
    result = []
    i = j = 0

    while i < len(left) and j < len(right):
        if left[i] > right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1

    result.extend(left[i:])
    result.extend(right[j:])
 
    return result

def Fractional_Knapsack(Capacity, Weights, Values):
    n = len(Values)

    Items = []

    for i in range(n):
        Ratio = Values[i]/Weights[i]
        Items.append((Ratio, Values[i], Weights[i]))

    # Items.sort(reverse = True)
    Items = MergeSort(Items)
    Total_Value = 0.0

    for Ratio, Values, Weights in Items:
        if Capacity >= Weights:
            Capacity -= Weights
            Total_Value += Values

        else:
            Total_Value += Ratio * Capacity
            break

    return Total_Value

Values = [100, 60, 120]
Weights = [20, 10, 30]
Capacity = 15

Result1 = Fractional_Knapsack(Capacity, Weights, Values)
print("Maximum Value in Knapsack : - ", round(Result1, 2))

Q17.Knapsack2.py

def QuickSort(array, low, high):
    if low < high:
        pivot = partition(array, low, high)
        QuickSort(array, low, pivot - 1)
        QuickSort(array, pivot + 1, high)

def partition(array, low, high):
    pivot = array[low]
    i = low + 1
    j = high

    while True:
        while i <= j and array[i] >= pivot:
            i += 1

        while i <= j and array[j] <= pivot:
            j -= 1 

        if i <= j:
            array[i], array[j] = array[j], array[i]

        else :
            break

    array[low], array[j] = array[j], array[low] 
    return j

def Fractional_Knapsack(Capacity, Weights, Values):
    n = len(Values)

    Items = []

    for i in range(n):
        Ratio = Values[i]/Weights[i]
        Items.append((Ratio, Values[i], Weights[i]))

    Items.sort(reverse = True)
    Total_Value = 0.0

    for Ratio, Values, Weights in Items:
        if Capacity >= Weights:
            Capacity -= Weights
            Total_Value += Values

        else:
            Total_Value += Ratio * Capacity
            break

    return Total_Value

Values = [100, 60, 120]
Weights = [20, 10, 30]
Capacity = 15

Result = Fractional_Knapsack(Capacity, Weights, Values)
print("Maximum Value in Knapsack : - ", round(Result, 2))

Q18.Knapsack_User.py

def Fractional_Knapsack(Capacity, Weights, Values):
    n = len(Values)

    Items = []

    for i in range(n):
        Ratio = Values[i]/Weights[i]
        Items.append((Ratio, Values[i], Weights[i]))

    Items.sort(reverse = True)
    Total_Value = 0.0

    for Ratio, Values, Weights in Items:
        if Capacity >= Weights:
            Capacity -= Weights
            Total_Value += Values

        else:
            Total_Value += Ratio * Capacity
            break

    return Total_Value

Names = []
Values = []
Weights = []
Item = []
Capacity = int(input("Enter Capacity : - "))

Size = int(input("Enter Size : -"))
for i in range(Size):
    Name = (input("Enter Name : - "))
    Value = int(input("Enter Value : - "))
    Weight = int(input("Enter Weight : - "))
    # Ratio = Value / Weight
    # Item.append(Ratio)
    Names.append(Name)
    Values.append(Value)
    Weights.append(Weight)
    Item.append((Name, Value, Weight))

print("\nList of Items : -")
print("Name    Value    Weight")

for Items in Item:
    print(f"{Items[0]} \t {Items[1]} \t {Items[2]}")
    # print("Name : - ", Names[i])
    # print("Values : - ", Values[i]) 
    # print("Weight : - ", Weights[i])

Result = Fractional_Knapsack(Capacity, Weights, Values)
print("Maximum Value in Knapsack : - ", round(Result, 2))

Q19.01Knapsack.py

def KnapsackRec(W, val, wt, n):
    if n == 0 or W == 0:
        return 0
    Pick = 0
        
    if wt[n-1] <= W:
        Pick = val[n-1] + KnapsackRec(W - wt[n-1], val, wt, n-1)
    Not_Pick = KnapsackRec(W, val, wt, n-1)
    return max(Pick, Not_Pick)

def Knapsack(W, val, wt):
    n = len(val)
    return KnapsackRec(W, val, wt, n)

if __name__ == "__main__":
    val = [1, 7, 11]
    wt = [1, 2, 3]
    W = 5
    print("Maximum Value in Knapsack : - ",Knapsack(W, val, wt))