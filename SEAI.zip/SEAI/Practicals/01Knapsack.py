def KnapsackRec(W, val, wt, n):
    if n == 0 or W == 0:
        return 0
    Pick = 0
        
    if wt[n-1] <= W:
        Pick = val[n-1] + KnapsackRec(W - wt[n-1], val, wt, n-1)
    Not_Pick = KnapsackRec(W, val, wt, n-1)
    return max(Pick, Not_Pick)

def Knapsack(W, val, wt):
    n = len(val)
    return KnapsackRec(W, val, wt, n)

if __name__ == "__main__":
    val = [1, 7, 11]
    wt = [1, 2, 3]
    W = 5
    print("Maximum Value in Knapsack : - ",Knapsack(W, val, wt))