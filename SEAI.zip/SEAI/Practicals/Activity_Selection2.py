def MergeSort(array):
    if len(array) <= 1:
        return array

    mid = len(array) // 2
    leftHalf = array[:mid]
    rightHalf = array[mid:]

    sortedLeft = MergeSort(leftHalf)
    sortedRight = MergeSort(rightHalf)

    return merge(sortedLeft, sortedRight)

def merge(left, right):
    result = []
    i = j = 0

    while i < len(left) and j < len(right):
        if left[i] < right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1

    result.extend(left[i:])
    result.extend(right[j:])
 
    return result

def Activity_Selection1(start,finish):
    Activities = list(zip(start,finish))
    MergeSort(finish)

    Selected = []
    Last_End = 0

    for s, f in Activities:
        if s >= Last_End:
            Selected.append((s,f))
            Last_End = f

    return Selected

start = [1, 3, 0, 5, 8, 5]
finish =[2, 4, 6, 7, 9, 9]

result = Activity_Selection1(start, finish)
print("Seleted Activities : - ", result)
print("Total Activities : - ", len(result))