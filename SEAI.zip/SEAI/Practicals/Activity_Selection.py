def Activity_Selection(start,finish):
    Activities = list(zip(start,finish))
    Activities.sort(key = lambda x : x[1])

    Selected = []
    Last_End = 0

    for s, f in Activities:
        if s >= Last_End:
            Selected.append((s,f))
            Last_End = f

    return Selected

start = [1, 3, 0, 5, 8, 5]
finish =[2, 4, 6, 7, 9, 9]

result = Activity_Selection(start, finish)
print("Seleted Activities : - ", result)
print("Total Activities : - ", len(result))