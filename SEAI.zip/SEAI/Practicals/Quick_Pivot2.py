def Quick_Pivot2(array, low, high): 
    if low < high:
        pivot = partition(array, low, high)
        Quick_Pivot2(array, low, pivot - 1)
        Quick_Pivot2(array, pivot + 1, high)

def partition(array, low, high):
    pivot = array[high]
    i = low 
    j = high - 1

    while True:
        while i <= j and array[i] <= pivot:
            i += 1

        while i <= j and array[j] >= pivot:
            j -= 1 

        if i <= j:
            array[i], array[j] = array[j], array[i]

        else :
            break

    array[i], array[high] = array[high], array[i] 
    return i

size = int(input("Enter Size : - "))
Number = input("Enter Array Sepreated by Space : - ")
num2 = list(map(int, Number.split()))
num3 = len(num2) - 1
if (len(num2) != size):
    print("Error : -")

else:
    Sorted_Array = Quick_Pivot2(num2, 0, num3)
    print("Sorted Array : - ", num2)

array = [64, 34, 25, 5, 22, 11, 90, 12]
num = len(array)- 1
Quick_Pivot2(array, 0, num)
print("Sorted Array : - ", array)