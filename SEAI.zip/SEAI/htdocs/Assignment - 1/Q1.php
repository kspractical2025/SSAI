<?php
$name = "Gupta Anuj";
$age = 21;
$city = "Ahmedabad";

echo "NAME :- $name <br>";
echo "AGE :- $age <br>";
echo "CITY :- $city";
?>