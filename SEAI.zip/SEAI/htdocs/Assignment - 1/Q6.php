<?php
$age = 20;

if($age >= 18) {
    echo "Eligible to Vote.";
} else {
    echo "Not Eligible to Vote.";
}

?>