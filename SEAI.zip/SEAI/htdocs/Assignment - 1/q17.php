<?php
$Friends = ["ar","king","om"];

foreach ($Friends as $name) {
    echo strtoupper ($name) . "<br>";
}

?>