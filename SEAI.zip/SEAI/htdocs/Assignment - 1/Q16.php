<?php
$colors = ["Red","Blue","Green","Yellow","Purple"];

foreach ($colors as $color) {
    echo "$color <br>";
}

?>