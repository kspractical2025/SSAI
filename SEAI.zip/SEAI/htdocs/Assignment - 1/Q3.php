<?php
$assignmentDone = true;

if($assignmentDone){
    echo "Assignment Completed.";
} else {
    echo "Assignment Not Completed.";
}

?>