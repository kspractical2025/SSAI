<?php
$name = $_POST ['name'];
$age = $_POST ['age'];

if (empty ($name)) {
    echo "Name is Required. <br>";
} else {
    echo "My Name : - $name <br>";
}

if (empty ($age)) {
    echo "Age is Required.";
} else {
    echo "I am  : - $age years old.";
}

?>