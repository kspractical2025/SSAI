<?php
$number = 5;

if ($number > 0) {
    echo "$number is positive.";
}