<?php
$name = "Bhagirath";     // String
$age = 21;               // Integer
$gpa = 7.5;              // Float
$isPassed = true;        // Boolean

echo "Name: $name<br>";
echo "Age: $age<br>";
echo "GPA: $gpa<br>";
echo "Passed: " . ($isPassed ? "Yes" : "No") . "<br />";

echo "<br /><br />";
echo 'Type of variable $name is: '.gettype($name). '<br />';
echo 'Type of variable $age is: '.gettype($age). '<br />';
echo 'Type of variable $gpa is: '.gettype($gpa). '<br />';
echo 'Type of variable $isPassed is: '.gettype($isPassed). '<br />'

?>