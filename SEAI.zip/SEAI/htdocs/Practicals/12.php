<?php
// process_get.php

// The data is passed via URL (visible in address bar)
// $_GET is used to retrieve the form values

$name = $_GET['username'];  // Get name from form
$age = $_GET['age'];        // Get age from form
$marks = $_GET['marks'];

echo "Hello, $name!<br>";
echo "You are $age years old.<br>";
echo "$marks";
?>